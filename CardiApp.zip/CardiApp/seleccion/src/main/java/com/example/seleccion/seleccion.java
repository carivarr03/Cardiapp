package com.example.seleccion;


import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import android.widget.RadioButton;

public class seleccion extends AppCompatActivity {




    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()) {
            case R.id.radio_neonato:
                if(checked)
                    break;
            case R.id.radio_Lactante:
                if(checked)
                break;
            case R.id.radio_Lactante_Mayor:
                if(checked)
                    break;
            case R.id.Preescolar:
                if(checked)
                    break;
            case R.id.Escolar:
                if(checked)
                    break;
            case R.id.Adolescente:
                if(checked)
                    break;
        }
    }
}