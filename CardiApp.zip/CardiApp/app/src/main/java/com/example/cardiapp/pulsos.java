package com.example.cardiapp;

public class pulsos {
    private String edad;
    private String frecuencia_vigilia_min;
    private String frecuencia_vigilia_max;
    private String frecuencia_min_reposo;
    private String frecuencia_max_reposo;
    public pulsos (String edad, String frecuencia_vigilia_min,
                   String frecuencia_vigilia_max, String frecuencia_min_reposo,
                   String frecuencia_max_reposo
    ){
this.edad = edad;
this.frecuencia_vigilia_min = frecuencia_vigilia_min;
this.frecuencia_vigilia_max = frecuencia_vigilia_max;
this.frecuencia_min_reposo = frecuencia_min_reposo;
this.frecuencia_max_reposo = frecuencia_max_reposo;
    }

    public String getEdad() {
        return edad;
    }

    public String getFrecuencia_vigilia_min() {
        return frecuencia_vigilia_min;
    }

    public String getFrecuencia_vigilia_max() {
        return frecuencia_vigilia_max;
    }

    public String getFrecuencia_min_reposo() {
        return frecuencia_min_reposo;
    }

    public String getFrecuencia_max_reposo() {
        return frecuencia_max_reposo;
    }
}

