package com.example.cardiapp;

import android.provider.BaseColumns;


public class pulsosDB {
    public static abstract class pulsosEntry implements BaseColumns{
        public static final String TABLE_NAME = "pulsos";
        public static final String EDAD = "edad";
        public static final String FRECUENCIA_VIGILIA_MIN = "frecuencia_vigilia_min";
        public static final String FRECUENCIA_VIGILIA_MAX = "frecuencia_vigilia_max";
        public static final String FRECUENCIA_MIN_REPOSO = "frecuencia_min_reposo";
        public static final String FRECUENCIA_MAX_REPOSO = "frecuencia_max_reposo";
    }
}
