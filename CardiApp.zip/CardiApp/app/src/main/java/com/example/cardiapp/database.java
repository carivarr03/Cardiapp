 package com.example.cardiapp;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class database extends SQLiteOpenHelper{

        private static final String COMMENTS_TABLE_CREATE = "CREATE TABLE `pulsos`(\n" +
                "`edad` varchar(40), \n" +
                "`frecuencia_vigilia_min` int, \n" +
                "`frecuencia_vigilia_max` int, \n" +
                "`frecuencia_min_reposo` int, \n" +
                "`frecuencia_max_reposo` int)";
        private static final String DB_NAME = "pulsos.db";
        private static final int DB_VERSION = 1;

        public database(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(COMMENTS_TABLE_CREATE);

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    

}

