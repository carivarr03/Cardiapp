package com.example.iniciar_sesion.ui.login;
import android.R.id;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.iniciar_sesion.R;

import org.json.JSONObject;

public class Sesion extends Activity {
    private EditText inputEmail;
    private EditText inputPassword;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        inputEmail = findViewById(R.id.txtEmail);
        inputPassword = findViewById(R.id.password);
        Button btnLogin = findViewById(R.id.login);


        btnLogin.setOnClickListener(new View.OnClickListener() {

            class Usuario {
                public void login(Sesion login, String email, String password) {
                }

                public void setOnLoginUsuario(OnLoginUsuario onLoginUsuario) {
                }
            }

            public void onClick(View view) {
                String email = inputEmail.getText().toString();
                String password = inputPassword.getText().toString();

                Usuario usuario = new Usuario();

                usuario.setOnLoginUsuario(new OnLoginUsuario() {
                    @Override
                    public void onLoginWrong(String msg) {

                    }

                    @Override
                    public void onLoginCorrect(JSONObject json, String msg) {

                    }


                    //@Override
                    //   public void onLoginCorrect(JSONObject json, String msg) {
                //     loginErrorMsg.setText("");
                  //      Intent itemintent = new Intent(Sesion.this, ActivityPrincipal.class);
                    //    Sesion.this.startActivity(itemintent);
                    //}

                });
                usuario.login(Sesion.this, email, password);
            }
        });

        TextView lblGotoRegister = (TextView) findViewById(id.accessibilityActionContextClick);
        lblGotoRegister.setOnClickListener(v -> {
            Intent itemintent = new Intent(Sesion.this, Register.class);
            Sesion.this.startActivity(itemintent);});
    }

    private abstract static class OnLoginUsuario {
        public abstract void onLoginWrong(String msg);

        public abstract void onLoginCorrect(JSONObject json, String msg);
    }

    private static class ActivityPrincipal {
    }

    private static class Register {
    }
}