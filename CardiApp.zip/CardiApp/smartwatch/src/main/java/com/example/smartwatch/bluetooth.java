package com.example.smartwatch;
import static android.provider.Telephony.Mms.Part.NAME;
import static com.google.android.gms.wearable.DataMap.TAG;
import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.util.Log;
import androidx.annotation.RequiresApi;
import androidx.annotation.RequiresPermission;
import java.io.IOException;
import java.util.UUID;
public class bluetooth {
    public void main(String[] args) {
//CONEXION
    BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    if(bluetoothAdapter == null){
        // Device doesn't support Bluetooth
    }
    if(!bluetoothAdapter.isEnabled()){
        Intent enableBtIntent = new Intent(bluetoothAdapter.ACTION_REQUEST_ENABLE);
        int REQUEST_ENABLE_BT = 0;
        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
    }




        final BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                   // String deviceName = device.getName();
                    String deviceHardwareAddress = device.getAddress(); // MAC address
                }
            }
            };

        Intent discoverableIntent =
                new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        startActivity(discoverableIntent);
        class AcceptThread extends Thread {
            private static final String TAG = "";
            private final BluetoothServerSocket mmServerSocket;
            @RequiresApi(api = Build.VERSION_CODES.S)
            @RequiresPermission(anyOf = {
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_ADMIN
            })
            public AcceptThread() {

                BluetoothServerSocket tmp = null;
                try {

                    // MY_UUID is the app's UUID string, also used by the client code.
                    UUID MY_UUID= UUID.randomUUID();
                    tmp = bluetoothAdapter.listenUsingRfcommWithServiceRecord(NAME, MY_UUID);
                } catch (IOException e) {
                    Log.e(TAG, "Socket's listen() method failed", e);
                }
                mmServerSocket = tmp;
            }
            public void run() {
                BluetoothSocket socket = null;
                // Keep listening until exception occurs or a socket is returned.
                while (true) {
                    try {
                        socket = mmServerSocket.accept();
                    } catch (IOException e) {
                        Log.e(TAG, "Socket's accept() method failed", e);
                        break;
                    }

                    if (socket != null) {
                        // A connection was accepted. Perform work associated with
                        // the connection in a separate thread.
                        manageMyConnectedSocket(socket);
                        try {
                            mmServerSocket.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    }
                }
            }

            private void manageMyConnectedSocket(BluetoothSocket socket) {
            }

            // Closes the connect socket and causes the thread to finish.
            public void cancel() {
                try {
                    mmServerSocket.close();
                } catch (IOException e) {
                    Log.e(TAG, "Could not close the connect socket", e);
                }
            }
        }
        }

    private void startActivity(Intent discoverableIntent) {

    }

    private void registerReceiver(Object o, IntentFilter filter) {
    }

    private void unregisterReceiver(BroadcastReceiver receiver) {

    }


    private static void startActivityForResult(Intent enableBtIntent, int requestEnableBt) {

    }


    private static class SavedInstanceState {

    }

    private class ConnectThread extends Thread{
        private final BluetoothSocket mmSocket;

        public ConnectThread(BluetoothDevice device) {
            BluetoothSocket tmp = null;
            mmSocket = tmp;


        }
        //permisos
        @RequiresApi(api = Build.VERSION_CODES.S)
        @RequiresPermission(anyOf = {
                Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_ADMIN
        })
        public void run() {

            BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            bluetoothAdapter.cancelDiscovery();

            try {
                mmSocket.connect();
            } catch (IOException connectException) {
                // Unable to connect; close the socket and return.
                try {
                    mmSocket.close();
                } catch (IOException closeException) {
                    Log.e(TAG, "Could not close the client socket", closeException);
                }
            }

            // Closes the client socket and causes the thread to finish.

        }
        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "Could not close the client socket", e);
            }

        }
        }

    private void manageMyConnectedSocket(BluetoothSocket mmSocket) {

    }
    }



